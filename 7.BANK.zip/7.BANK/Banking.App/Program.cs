﻿using Banking.Logic;

Console.WriteLine("Welcome to the banking app!");
Console.WriteLine("Type of account ([C]hecking, [b]usiness, [s]avings): ");
char type = char.Parse(Console.ReadLine()!);

Account account = type switch
{
    'c' => new CheckingAccount(),
    'b' => new BusinessAccount(),
    's' => new SavingsAccount(),
    _ => throw new ArgumentException("Invalid account type")
};

Console.WriteLine("Please enter the Account Number: ");
account.AccountNumber = Console.ReadLine()!;

Console.WriteLine("Please enter the Account Holder:  ");
account.AccountHolder = Console.ReadLine()!;

Console.WriteLine("Please enter the current balance:  ");
account.CurrentBalance = decimal.Parse(Console.ReadLine()!);

Transaction transaction = new Transaction();

Console.WriteLine("Please enter the Transaction Account Number: ");
transaction.AccountNumber = Console.ReadLine()!;

Console.WriteLine("Please enter the Transaction Description: ");
transaction.Description = Console.ReadLine()!;

Console.WriteLine("Please enter the Amount:  ");
transaction.Amount = decimal.Parse(Console.ReadLine()!);

Console.WriteLine("Please enter the Transaction Timestamp (YYYY-MM-DD'T'hh:mm:ss): ");
transaction.Timestamp = DateTime.Parse(Console.ReadLine()!);

if (account.TryExecute(transaction) && !(account.CurrentBalance < -10_000))
{
    Console.WriteLine($"Transaction executed successfully. The new current balance is {account.CurrentBalance}");
}

else Console.WriteLine($"Transaction not allowed");

