﻿namespace Banking.Logic;

public class SavingsAccount : Account
{
    public override bool IsAllowed(Transaction t)
    {
        if (t.Amount >= 0 && t.Amount <= 100_000_000 && t.AccountNumber == AccountNumber)
        {
            return true;
        }
        return false;
    }
}
