﻿namespace Banking.Logic;

public abstract class Account
{
    public string AccountNumber { get; set; }
    public string AccountHolder { get; set; }
    public decimal CurrentBalance { get; set; }
    public abstract bool IsAllowed(Transaction transaction);

    public bool TryExecute(Transaction transaction)
    {
        if (IsAllowed(transaction) == true)
        {
            CurrentBalance = CurrentBalance + transaction.Amount;
            return true;
        }
        return false;
    }
}
