﻿namespace Banking.Logic;

public class CheckingAccount : Account
{
    public override bool IsAllowed(Transaction t)
    {
        if (t.Amount >= -10_000 && t.Amount <= 10_000_000 && t.AccountNumber == AccountNumber)
        {
            return true;
        }
        return false;
    }
}

